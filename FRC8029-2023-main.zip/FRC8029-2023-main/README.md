# FRC8029-2023
Auton Priority
Mobility: Leave community(3pt)
This is simple. Just move forward or backward with respect to orientation.
Docking on charge station (8/12 pts)
This would require coordination and docking. I think we would need three or at least two separate autonomous codes due to where we are on the field. 
Mr. Cullen has recommended sensors. This will be pushed back or reach a goal. 
If in the future we want to place a cone or cube, we probably will need to use vision. 



Tele-op Priority 
Endgame(6 - 10pts)
Docking on the charger station is a priority. Please coordinate with auton so we can talk about sensors. 
This needs to work on the arms of any other robot moving. 
We are going to go with cubes and cones(2nd and 3rd). This requires going up and going forward. These will be prototypes by the mechanical team. This is going to be seen later. 
We will need a dashboard working. This dashboard is a priority and is needed to switch between auton, seeing the camera, knowing distance and other information. Again, all of this will be seen on the primary computer(the one with no battery). Finally, last year I think we used SmartDashboard- I think we need to code this. 




Vision - Daniel
I think we are doing the limelight and camera this year. 
Limelight
Limelight takes measurements in which we can then transform to distance and aiming. We have previous code you can use.
Camera
Use limelight reflection to triangulate position based on the bearings to pegs
If you want to be adventurous, find a way to combine both and we can create a more advanced vision system, maybe using Jetson or something like that.



Swerve Drive
We are doing this from scratch
We need to wait for mechanical to fix for testing
